public class Cola {
  private int[] vec;
  private int p, u;
  private final int MAX;

  public Cola(int n) {
    this.MAX = n;
    this.vec = new int[MAX];
    this.p = -1;
    this.u = -1;
  }

  public boolean estaLlena() {
    return u >= MAX - 1;
  }

  public boolean estaVacia() {
    return p == -1;
  }

  public boolean agregar(int dato) {
    if (!estaLlena()) {
      vec[++u] = dato;
      if (u == 0)
        p = 0;
      return true;
    }
    return false;
  }

  public Integer extraer() {
    if (!estaVacia()) {
      int dato = vec[p];
      if (p == u) {
        p = -1;
        u = -1;
      } else {
        p++;
      }
      return dato;
    }
    return null;
  }
}
