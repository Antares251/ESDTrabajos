public class Pila {
  private int[] datos;
  private int tope;
  private final int tam;

  public Pila(int n) {
    this.tam = n;
    this.datos = new int[tam];
    this.tope = -1;
  }

  public boolean push(int valor) {
    if (tope >= tam - 1) {
      System.out.println("OVERFLOW");
      return false;
    } else {
      datos[++tope] = valor;
      return true;
    }
  }

  public Integer pop() {
    if (tope == -1) {
      System.out.println("UNDERFLOW");
      return null;
    } else {
      return datos[tope--];
    }
  }

  public void mostrar() {
    for (int i = 0; i <= tope; i++) {
      System.out.println("Dato[" + i + "] -> " + datos[i]);
    }
  }
}
