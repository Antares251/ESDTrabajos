public class ListaEnlazada {
  private class Nodo {
    int info;
    Nodo sig;

    Nodo(int info) {
      this.info = info;
      this.sig = null;
    }
  }

  private Nodo cabeza;

  public void insertar(int dato) {
    Nodo nuevo = new Nodo(dato);
    if (cabeza == null) {
      cabeza = nuevo;
    } else {
      Nodo aux = cabeza;
      while (aux.sig != null) {
        aux = aux.sig;
      }
      aux.sig = nuevo;
    }
  }

  public void mostrar() {
    Nodo aux = cabeza;
    while (aux != null) {
      System.out.print(aux.info + " -> ");
      aux = aux.sig;
    }
    System.out.println("NULL");
  }
}
