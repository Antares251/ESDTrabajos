import java.util.Scanner;

public class AppPilas {
  public static void main(String[] args) {
    Pila pila = new Pila(5);
    Scanner sc = new Scanner(System.in);
    int op;

    do {
      System.out.println("1) Push\n2) Pop\n3) Salir");
      op = sc.nextInt();

      if (op == 1) {
        System.out.print("Dato: ");
        pila.push(sc.nextInt());
        pila.mostrar();
      } else if (op == 2) {
        Integer d = pila.pop();
        if (d != null)
          System.out.println("Eliminado: " + d);
        pila.mostrar();
      }
    } while (op != 3);
  }
}
